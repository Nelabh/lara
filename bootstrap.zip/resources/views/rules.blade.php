@extends('common.default')



@section('content')

<div class="container-fluid about-background">
            <div class="row content">
                <div class="col-md-offset-4 col-md-4">
                    <h3 class="animated fadeInDown">
                    Rules:
                    </h3>
                    <ul class="rules">
                    <li>
                        This is an ONLINE event which will be live for two days (28 Sept 2015 to 30 Sept 2015).
                        </li>
                        <li>
                        Each question will bring you closer to your destination.
                        </li>
                        <li>
                        Each level will take you to the two paths. One of which is going to be the technical one and other is the non-technical one!
                        </li>
                        <li>
                        The TECHNICAL answer will earn you 10 points and the NON-TECHNICAL answerwill earn you 5 points.
                        </li>
                        <li>
                       The answers are to be written only in lowercase. Special symbols and numerics are allowed and spaces are not allowed.Example : If an answer is "christopher nolan" submit it as "christophernolan".
                        </li>
                        <li>
                        The HINTS to each level will be disclosed on the FORUM of *facebook* page NIBBLE COMPUTER SOCIETY (NCS).
                        </li>
                        <li>
                            Please do not message personally on the page or anybody related to NCS regarding hints. Every possible hint for each level will be displayed on the page itself!
                        </li>
                        <li>
                           In case of any discrepancy, the judgement of Nibble Computer Society will be the final one.
                        </li>
                        <li>
                        The winner will be announced on the Facebook page and on the Infocentre as well, after the game terminates.
                    </li>
                    <li>
                        In recognition of an outstanding achievement, the winner will be rewarded by getting a great chance to sit directly in the second round of the NCS recruitment session.
                    </li>
                    </ul>
                </div>
            </div>
        </div>

@stop